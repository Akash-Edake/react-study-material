export const data={
    product:[
        {
            id:1,
            title:"Kulangot",
            desc:"salt",
            price:"67"
        },
        {
            id:2,
            title:"Tiktilaok Manok",
            desc:"Salt maalat",
            price:"78"
        },
        {
            id:3,
            title:"Very Nice",
            desc:"Yezyow",
            price:"79"
        },
        {
            id:4,
            title:"Balakubak",
            desc:"Betsin Maalat",
            price:"170"
        }
    ]
}