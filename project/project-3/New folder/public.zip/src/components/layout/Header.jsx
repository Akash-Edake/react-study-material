import React from "react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Home from "../pages/Home";
function Header() {
  const [Filter, setFilter] = useState("");
  const [Filter2, setFilter2] = useState([]);
  const [Count, setCount] = useState(0);
  const [Json, setjson] = useState([]);

  useEffect(() => {
    fun();
  }, []);
  const fun = async () => {
    let a = await axios.get("http://localhost:3003/posts");
    setjson(a.data);
  };
  console.table(Json);

  const Addbutton = (para) => {
    let data = Json.filter((val) =>
      val.name.toLowerCase().includes(para.toLowerCase())
    );
    setFilter2(data);
  };
  console.log(Filter2);
  return (
    <>
      <section>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark pt-3">
          <div className="container-fluid">
            <div className="row w-100">
              <div className=" col-sm-12 col-lg-7">
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div
                  className="collapse navbar-collapse"
                  id="navbarSupportedContent"
                >
                  <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                    <li className="nav-item">
                      {/* <Link className="nav-link" to={'/'}>Home</Link> */}
                    </li>
                    <li className="nav-item">
                      {/* <Link className="nav-link active" aria-current="page" to={'/'}>Shop</Link> */}
                    </li>
                    <li className="nav-item">
                      {/* <Link className="nav-link" to={'/'}>Featured</Link> */}
                    </li>

                    <li className="nav-item">
                      {/* <Link className="nav-link">Recommended</Link> */}
                    </li>
                  </ul>
                  <form className="d-flex" role="search">
                    <input
                      className="form-control me-2"
                      type="search"
                      placeholder="Search"
                      aria-label="Search"
                      onChange={(e) => {
                        setFilter(e.target.value);
                      }}
                    />
                    {/* <button className="btn btn-outline-success" type="submit">Search</button> */}
                  </form>
                </div>
              </div>
              <div className="col-sm-12 col-lg-5">
                <form className="d-flex justify-content-end">
                  <button
                    className="btn btn-outline-success me-2"
                    type="button"
                  >
                    Sign In
                  </button>
                  <button
                    className="btn btn-outline-secondary me-2"
                    type="button"
                  >
                    SignUp
                  </button>
                  <button
                    type="link"
                    className="position-relative bg-transparent text-white shadow-none border-0"
                  >
                    <span className="fs-4">
                      <i class="fa-solid fa-cart-shopping"></i>{" "}
                    </span>
                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                      {Count}
                      <span className="visually-hidden">unread messages</span>
                    </span>
                  </button>

                  <button className="btn text-white me-2">Cart</button>
                </form>
              </div>
            </div>
          </div>
        </nav>
      </section>

      <section>
        <div className="container">
          <div className="row">
            <div className="col-12" style={{ display: "contents" }}>
              {Json.filter((value) => {
                if (value === "") {
                  return value;
                } else if (
                  value.name.toLowerCase().includes(Filter.toLowerCase())
                ) {
                  return value;
                }
              }).map((data) => {
                return (
                  <div className="col-2 m-2 shadow-lg bg-body rounded">
                    <div className="card">
                      <img
                        src="https://firebasestorage.googleapis.com/v0/b/salinaka-ecommerce.appspot.com/o/products%2FYIZuxWur1W4fAT6z3ejk?alt=media&token=7dca264f-c345-4cfc-93a8-60217a53f66a"
                        className="card-img-top"
                        alt="..."
                      />
                      <div className="card-body">
                        <h5 className="card-title">{data.name}</h5>
                        <p className="card-text">{data.type}</p>
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            Addbutton(data.name);
                            setCount(Count + 1);
                          }}
                        >
                          add
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
      <section>
        <table class="table table-striped col-8">
          {Filter2.map((item, index) => {
            let { name, type, price } = item;
            return (
              <tr>
                <td>
                  <img  src="https://firebasestorage.googleapis.com/v0/b/salinaka-ecommerce.appspot.com/o/products%2FYIZuxWur1W4fAT6z3ejk?alt=media&token=7dca264f-c345-4cfc-93a8-60217a53f66a"  alt="..."/>
                </td>
                <td scope="col" key={index}>
                  {name}{" "}
                </td>
                <td scope="col" key={index}>
                  {type}{" "}
                </td>
                <td scope="col" key={index}>
                  {price}{" "}
                </td>
                <td>
                  <button onClick={() => price + 1}>+</button>{" "}
                </td>
              </tr>
            );
          })}
        </table>
      </section>
    </>
  );
}

export default Header;
