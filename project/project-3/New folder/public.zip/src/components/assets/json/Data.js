export const Data=[
{name:'Kulangot', type:'salt',price:67},
{name:'Tiktilaok Manok', type:'Sexbomb',price:78},
{name:'Very Nice', type:'Salt maalat',price:79},
{name:'Quake Overload', type:'Yezyow',price:80},
{name:'Kutu', type:'Sexbomb',price:129},
{name:'Balakubak', type:'Betsin Maalat',price:170},
{name:'Sipon Malapot', type:'salt',price:250},
]