import React, {useEffect, useState} from 'react'
import ItemCard from './ItemCard'
import { data } from './data'
import axios from 'axios';
function Home() {
  
  const [Filter, setFilter] = useState("");
  const [Json, setJson] = useState([]);
  useEffect(()=>{
    GetData()
  },[])
  const GetData=async()=>{
    let data = await axios.get("http://localhost:3003/product")
    setJson(data.data)
  }
  return (
    <>
     <section>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark pt-3">
          <div className="container-fluid">
            <div className="row w-100">
              <div className=" col-sm-12 col-lg-7">
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div
                  className="collapse navbar-collapse"
                  id="navbarSupportedContent"
                >
                  <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                    <li className="nav-item">
                      {/* <Link className="nav-link" to={'/'}>Home</Link> */}
                    </li>
                    <li className="nav-item">
                      {/* <Link className="nav-link active" aria-current="page" to={'/'}>Shop</Link> */}
                    </li>
                    <li className="nav-item">
                      {/* <Link className="nav-link" to={'/'}>Featured</Link> */}
                    </li>

                    <li className="nav-item">
                      {/* <Link className="nav-link">Recommended</Link> */}
                    </li>
                  </ul>
                  <form className="d-flex" role="search">
                    <input
                      className="form-control me-2"
                      type="search"
                      placeholder="Search"
                      aria-label="Search"
                      onChange={(e) => {
                        setFilter(e.target.value);
                      }}
                    />
                    {/* <button className="btn btn-outline-success" type="submit">Search</button> */}
                  </form>
                </div>
              </div>
              <div className="col-sm-12 col-lg-5">
                <form className="d-flex justify-content-end">
                  <button
                    className="btn btn-outline-success me-2"
                    type="button"
                  >
                    Sign In
                  </button>
                  <button
                    className="btn btn-outline-secondary me-2"
                    type="button"
                  >
                    SignUp
                  </button>
                  <button
                    type="link"
                    className="position-relative bg-transparent text-white shadow-none border-0"
                  >
                    <span className="fs-4">
                      <i class="fa-solid fa-cart-shopping"></i>{" "}
                    </span>
                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                      .
                      <span className="visually-hidden">unread messages</span>
                    </span>
                  </button>

                  <button className="btn text-white me-2">Cart</button>
                </form>
              </div>
            </div>
          </div>
        </nav>
      </section>
   
        <div className="containet m-5">
            <div className="row">
                <div className="col-12 " style={{display:"contents"}}>
                  {
                    Json.filter((value) => {
                      if (value === "") {
                        return value;
                      } else if (value.title.toLowerCase().includes(Filter.toLowerCase())) {
                        return value;
                      }
                    }).map((item,index)=>{
                      const {title,desc,price}=item
                      return(
                        <ItemCard title={title} desc={desc} item={item} price={price} key={index} />
                      )
                    })
                  }
                </div>
            </div>
        </div>
    </>
  )
}

export default Home