import "./App.css";
// import Header from "./components/layout/Header";
import Card from "./components/pages/Card";
import Home from "./components/pages/Home";
import { CartProvider } from "react-use-cart";

function App() {
  return (
    <>
      {/* <Header/> */}
      <CartProvider>
        <Home />
        <Card />
      </CartProvider>
    </>
  );
}

export default App;
